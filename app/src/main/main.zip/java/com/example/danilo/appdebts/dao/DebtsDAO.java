package com.example.danilo.appdebts.dao;

/**
 * Created by aluno on 27/06/19.
 */

public class DebtsDAO {
}
