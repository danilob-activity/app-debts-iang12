package com.example.danilo.appdebts.classes;

/**
 * Created by aluno on 27/06/19.
 */

public class Debts {
    private long mId;
    private Category mCategory;

    private float Value;
    private String mPaymentDate;
    private String mPayDate;
    public Debts(long id, Category category, float value, String paymentDate, String payDate) {
        mId = id;
        mCategory = category;
        Value = value;
        mPaymentDate = paymentDate;
        mPayDate = payDate;
    }

    public long getId() {
        return mId;
    }

    public void setId(long id) {
        mId = id;
    }

    public Category getCategory() {
        return mCategory;
    }

    public void setCategory(Category category) {
        mCategory = category;
    }

    public float getValue() {
        return Value;
    }

    public void setValue(float value) {
        Value = value;
    }

    public String getPaymentDate() {
        return mPaymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        mPaymentDate = paymentDate;
    }

    public String getPayDate() {
        return mPayDate;
    }

    public void setPayDate(String payDate) {
        mPayDate = payDate;
    }
}
